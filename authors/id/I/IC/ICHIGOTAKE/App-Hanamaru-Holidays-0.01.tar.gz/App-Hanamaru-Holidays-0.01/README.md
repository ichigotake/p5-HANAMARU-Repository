# NAME

App::Hanamaru::Holidays - 月の休日の一覧を出力します。

# SYNOPSIS

    $ carton install && carton exec -- plackup
    

# TODO

\- 振り替え休日が考慮されていない

\- 依存モジュールの定義ファイルを設置

\- JSONレスポンス

\- WEBフォーム

# AUTHOR

ichigotake
