# NAME

App::Hanamaru::Note - はなまる手帳

# SYNOPSIS

    $ plackup

# DESCRIPTION

Hanamaru::Note is post to "Hanamaru word" web application.

"Hanamaru" mean "flower circle", its offen used praise children.

# AUTHOR

ichigotake

# SEE ALSO

Nephia

Google Image Search: "はなまる"

# LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
